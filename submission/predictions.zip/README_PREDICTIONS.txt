=================================================================
 NEBULA-X 2026: UNIFIED CONDITION MONITORING PREDICTIONS PACKAGE
 Problem Statement 3: Advanced Train Condition Monitoring
=================================================================

This archive contains complete predicted test cases across all four subsystems:

  [✓] rail_predictions.csv           ( 68 records) -> PS3 Subsystem 3: Rail Corrugation Anomaly Detection & Bilateral Localization (68 recordings)
  [✓] shm_predictions.csv            ( 16 records) -> PS3 Subsystem 4: Structural Health Monitoring Fatigue Damage Index (16 recordings)
  [✓] acv_predictions.csv            (  1 records) -> PS3 Subsystem 2: ACV Refrigerant-Leak Fault Localization & Consist Ranking (6 cases)
  [✓] door_predictions.csv           ( 38 records) -> PS3 Subsystem 1: Train Doors Resistance Classification & Cycle Segmentation (38 cycles)
  [✓] rail_predictions_detailed.csv  ( 68 records) -> Rail Corrugation Detailed Diagnostic Features (Speed, SDI, Confidence)

Subsystem Details:
1. rail_predictions.csv : 68 test files (Normal, Side I Left, Side II Right corrugation)
2. shm_predictions.csv  : 16 test files (Continuous fatigue damage index D from strain telemetry)
3. acv_predictions.csv  : 6 cases (Ranked sequence, e.g. 01|04|08... pointing to Car 01)
4. door_predictions.csv : 38 door cycles (Normal vs Abnormal Resistance at 50Hz)

Platform URL: https://nebula-rail-twin-515716532383.asia-southeast1.run.app